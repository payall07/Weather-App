//
//  ViewController.swift
//  Assignment_Weather_App
//
//  Created by Aditya Singh on 27/07/21.
//

import UIKit
import CoreLocation
import Foundation
//location: coreLocation
//API to get the data.


class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, CLLocationManagerDelegate {

    @IBOutlet var table: UITableView!

    var modelsArray =  [Daily]()
    var locationManager = CLLocationManager()
    
    var currentLocation : CLLocation?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //Register a cell
        table.register(WeatherTableViewCell.nib(), forCellReuseIdentifier: WeatherTableViewCell.identifier)
        
        table.delegate = self
        table.dataSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        setupLocation()
    }
    
    //location
        //Getting location for the first time. (Location of simulator is set to Apple which may give the location of San Francisco)
    func setupLocation(){
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()  //Check for it's use
    }
    
    /*
     *  locationManager:didUpdateLocations:
     *
     *  Discussion:
     *    Invoked when new locations are available.  Required for delivery of
     *    deferred locations.  If implemented, updates will
     *    not be delivered to locationManager:didUpdateToLocation:fromLocation:
     *
     *    locations is an array of CLLocation objects in chronological order.
     */
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if !locations.isEmpty, currentLocation == nil {
            currentLocation = locations.first
            locationManager.stopUpdatingLocation()
                //
            requestWeatherForLocaiton()
        }
    }
    
    //https://api.openweathermap.org/data/2.5/onecall?lat=37.3323&lon=122.0312&exclude=[flag,hourly,minutely]&appid=df9f0eb88d60416d438b2cc783994e35&units=metric
    
    func requestWeatherForLocaiton(){
        guard let currentLocation = currentLocation else {
            return
        }
        let long = currentLocation.coordinate.longitude
        let lat = currentLocation.coordinate.latitude
        
        //https://api.openweathermap.org/data/2.5/onecall?lat=37.33233141&lon=122.&exclude=[flag,minutely]&appid=df9f0eb88d60416d438b2cc783994e35&units=metric
        let url = "https://api.openweathermap.org/data/2.5/onecall?lat=\(lat)&lon=\(long)&exclude=[flag,minutely]&appid=df9f0eb88d60416d438b2cc783994e35&units=metric"
        
      print("\(long) | \(lat)") // for console print
        
        URLSession.shared.dataTask(with: URL(string: url)!, completionHandler: {data, response, error in
            
            //validation
            guard let data = data, error == nil else{
                print("error occured")
                return
            }
            
            // Convert data to models/some object

            var json: WeatherResponse?
            do {
                let decoder = JSONDecoder()
                                decoder.keyDecodingStrategy = .convertFromSnakeCase
                json = try decoder.decode(WeatherResponse.self, from: data) //decoder
            }
            catch {
                print("error: \(error)")
            }
            
            guard let result = json else {
                return
            }
//            print(result.daily[2].temp.day)
            let entries = result.daily
            
            self.modelsArray.append(contentsOf: entries)

//            let current = result.current
//            self.current = current
            
            // Update user interface
            DispatchQueue.main.async {
                self.table.reloadData()

//                self.table.tableHeaderView = self.createTableHeader()
            }
            
        }).resume()
    }
    
    
    //Table
            //Number of rows in the table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return modelsArray.count
    }
            //cell for each row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: WeatherTableViewCell.identifier, for: indexPath) as! WeatherTableViewCell
        cell.configure(with: modelsArray[indexPath.row])
//        cell.weatherConfig(with: modelForWeather[indexPath.row])
        return cell
    }

}


struct WeatherResponse: Decodable {
    let lat: Double?
    let lon: Double?
    let timezone: String?
    let timezone_offset: Int?
    var current: Current
//    var minutely: Minutely
    var hourly: [Hourly]
    var daily: [Daily]
}

struct Current: Decodable{
    let dt,sunrise,sunset: Int?
//    let sunrise: Int
//    let sunset: Int
    let temp,feels_like: Double?
//    let feels_like: Double
    let pressure: Int?
    let humidity: Int?
    let dew_point: Double?
    let uvi: Double?
    let clouds: Int?
    let visibility: Int?
    let wind_speed: Double?
    let wind_deg: Int?
    let wind_gust: Double?
    var weather: [Weather]
}

struct Weather: Decodable {
    let id: Int?
    let main: String?
    let description: String?
    let icon: String?
}

//struct Minutely: Decodable {
//    let dt: Int?
//    let precipitation: Int?
//}

struct Hourly: Decodable {
    let dt: Int?
    let temp: Double?
    let feels_like: Double?
    let pressure: Int?
    let humidity: Int?
    let dew_point: Double?
    let uvi: Double?
    let clouds: Int?
    let visibility: Int?
    let wind_speed: Double?
    let wind_deg: Int?
    let wind_gust: Double?
    var weather: [Weather]
    let pop: Int?
}

struct Daily: Decodable {
    let dt,sunrise,sunset,moonset: Int?
//    let sunrise: Int
//    let sunset: Int
//    let moonset: Int
    let moon_phase: Double?
    var temp: Temp
    var feels_like: Feels_like?
    let pressure,humidity: Int?
//    let humidity: Int
    let dew_point: Double?
    let wind_speed: Double?
    let wind_deg: Int?
    let wind_gust: Double?
    var weather: [Weather]
    let clouds: Int?
    let pop: Double?
    let rain: Double?
    let uvi: Double?
}

struct Temp: Decodable {
    let day,min,max,night,eve,morn: Double?
//    let min: Double
//    let max: Double
//    let night: Double
//    let eve: Double
//    let morn: Double
}

struct Feels_like: Decodable{
    let day,night,eve,morn: Double?
//    let night: Double
//    let eve: Double
//    let morn: Double
}
