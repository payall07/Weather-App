//
//  WeatherTableViewCell.swift
//  Assignment_Weather_App
//
//  Created by Aditya Singh on 28/07/21.
//

import UIKit

class WeatherTableViewCell: UITableViewCell {

    @IBOutlet var dayLabel: UILabel!
    @IBOutlet var dayTemp: UILabel!
    @IBOutlet var dayDescrip: UILabel!
    @IBOutlet var iconImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    static let identifier = "WeatherTableViewCell"
    
    static func nib() -> UINib{
        return UINib(nibName: "WeatherTableViewCell", bundle: nil)
    }
    
    
    func configure(with model: Daily){
        self.dayTemp.text = "\(Int(model.temp.day!))°"
            
        self.weatherConfig(with: model.weather[0])
        
//        let iconImage = value
//        if let iconImage = value
//                            {
//                                let appImage = UIImage(data: iconImage)
//                                self.iconImageView.image = appImage
//                            }
        self.dayLabel.text = getDayForDate(Date(timeIntervalSince1970: Double(model.dt!)))
    }
    
    func weatherConfig(with modelWeather: Weather) {
        self.dayDescrip.text = "\(modelWeather.description ?? "NA")"
        do {
            guard let imageUrl = URL(string: "http://openweathermap.org/img/w/\(modelWeather.icon ?? "na").png") else { print("problem in url")
                return  }
            let imageData = try Data(contentsOf: imageUrl)
            guard let image = UIImage(data: imageData) else { return  }
            self.iconImageView.image = image
        }catch{
            print(error.localizedDescription)
        }
//            Daily.weather.index(before: 3)
    }

    
    func getDayForDate(_ date: Date?) -> String {
        guard let inputDate = date else {
            return ""
        }

        let formatter = DateFormatter()
        formatter.dateFormat = "EEEE" // Monday
        return formatter.string(from: inputDate)
    }


}
